$.lang.register('cliphandler.toggle.off', 'Clips Benachrichtigungen wurde deaktiviert!');
$.lang.register('cliphandler.toggle.on', 'Clips Benachrichtigungen wurden aktiviert!');
$.lang.register('cliphandler.message.usage', 'Verwendung: !clipsmessage (Nachricht) - Tags: (name), (url)');
$.lang.register('cliphandler.message.set', 'Clips Nachricht wurde festgelegt zu: $1.');
$.lang.register('cliphandler.channel.usage', 'Verwendung: !clipschannel (Kanal).  Aktuell: $1');
$.lang.register('cliphandler.channel.set', 'Clips Benachrichtigungskanal wurde festgelegt zu: $1.');
$.lang.register('cliphandler.noclip', 'Kein Clip gefunden!');
$.lang.register('cliphandler.lastclip', 'Letzter Clip: $1');
$.lang.register('cliphandler.topclip', 'Heute meist gesehenster Clip: $1');
