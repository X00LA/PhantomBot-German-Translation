$.lang.register('wordcounter.usage', 'Verwendung: !wordcounter [add / remove] !count [Wort]');
$.lang.register('wordcounter.add.usage', 'Verwendung: !wordcounter add [Wort]');
$.lang.register('wordcounter.added', ' wurde der Wort-Zähl-Liste hinzugefügt!');
$.lang.register('wordcounter.remove.usage', 'Verwendung: !wordcounter remove [Wort]');
$.lang.register('wordcounter.err.404', 'Dieses Wort ist nicht in der Zähler-Liste.');
$.lang.register('wordcounter.removed', ' wurde aus der Zähler-Liste entfernt!');
$.lang.register('wordcounter.count', '$1 wurde $2 Mal gesagt.');
