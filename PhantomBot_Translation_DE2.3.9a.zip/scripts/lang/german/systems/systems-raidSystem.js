$.lang.register('raidsystem.raid', 'Wir überfallen http://twitch.tv/$1 ! $2');
$.lang.register('raidsystem.raid.usage', 'Verwendung: !raid [Benutzername]');
$.lang.register('raidsystem.raided', 'Wir wurden von $1 überfallen! Das ist das $2 Mal, dass wir von $1 überfallen wurden. Geh und schau dir den Kanal http://twitch.tv/$1 mal an, und natürlich das anklicken des Follow-Buttons nicht vergessen!');
$.lang.register('raidsystem.raider.usage', 'Verwendung: !raider [Benutzername] -- !raider count [Benutzername]');
$.lang.register('raidsystem.message.nomessageset', '$1 hat noch keine Überfallsnachricht festgelegt! Verwende "!setraidmsg [Nachricht...]" um eine festzulegen.');
$.lang.register('raidsystem.message.usage', 'Verwendung: "!setraidmsg [Nachricht...]" um eine zu Nachricht festzulegen.');
$.lang.register('raidsystem.message.setsuccess', 'Die neue Überfalls-Nachricht lautet "$1".');
$.lang.register('raidsystem.console.announceraidmsg', 'Die aktuelle Überfallsnachricht lautet "$1".');