$.lang.register('slotmachine.result.start', '$1: [ $2 $3 $4 ] ');
$.lang.register('slotmachine.result.win', ' +$1 ');
$.lang.register('slotmachine.rewards.usage', 'Verwendung: !slot rewards [val1] [val2] [val3] [val4] [val5]. Aktuell: $1');
$.lang.register('slotmachine.rewards.success', 'Gewinne für einarmigen Banditen aktualisiert.');
$.lang.register('slotmachine.emote.usage', 'Verwendung: !slot emotes [emote1] [emote2] [emote3] [emote4] [emote5]. Aktuell: $1');
$.lang.register('slotmachine.emote.success', 'Emotes für einarmigen Banditen aktualisiert.');
