$.lang.register('roll.rolled', '$1 würfelt eine [$2] und [$3]. ');
$.lang.register('roll.doubleone', 'Schlangenaugen für $1! ');
$.lang.register('roll.doubletwo', 'Zweierpasch für $1! ');
$.lang.register('roll.doublethree', 'Dreierpasch für $1! ');
$.lang.register('roll.doublefour', 'Viererpasch für $1! ');
$.lang.register('roll.doublefive', 'Fünferpasch für $1! ');
$.lang.register('roll.doublesix', 'SECHSERPASCH für $1! ');
$.lang.register('roll.rewards.usage', 'Verwendung: !roll rewards [double 1\'s] [2\'s] [3\'s] [4\'s] [5\'s] [6\'s]. Aktuell: $1');
$.lang.register('roll.rewards.success', 'Gewinne für das Würfeln aktualisiert.');
