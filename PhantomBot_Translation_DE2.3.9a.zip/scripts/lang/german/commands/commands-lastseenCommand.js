$.lang.register('lastseen.404', 'Ich habe $1 noch nicht gesehen.');
$.lang.register('lastseen.response', '$1 wurde zuletzt um $2 @ $3 gesehen.');
$.lang.register('lastseen.usage', 'Verwendung: !lastseen [BenutzerInnenname].');