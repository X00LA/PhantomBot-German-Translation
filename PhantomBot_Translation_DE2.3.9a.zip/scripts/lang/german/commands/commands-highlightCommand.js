$.lang.register('highlightcommand.highlight.offline', 'Höhepunkte können nur gesetzt werden, wenn der Stream online ist!');
$.lang.register('highlightcommand.highlight.usage', 'Verwendung: !highlight [Beschreibung] (Verwende Datumsstempel für Zeitzone: $1)');
$.lang.register('highlightcommand.highlight.success', 'Höhepunkt erfolgreich mit Zeitstempel, $1, gespeichert.');
$.lang.register('highlightcommand.gethighlights.no-highlights', 'Es liegen aktuell keine Höhepunkte vor.');
$.lang.register('highlightcommand.clearhighlights.success', 'Höhepunkte wurden bereinigt!');
$.lang.register('highlightcommand.highlights', 'Höhepunkte: $1');
