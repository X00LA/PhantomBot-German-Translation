$.lang.register("deathcounter.set-error", "Gib einen neuen, gültigen Todeszählerwert ein.");
$.lang.register("deathcounter.set-success", "Todeszähler für $1 auf $2 geändert.");
$.lang.register("deathcounter.add-success", "$1 ist in $2 wieder gestorben, womit die Gesamtzahl auf $3 steigt.");
$.lang.register("deathcounter.sub-success", "Rücknahme eines Todes, die Gesamtzahl ist jetzt $2 in $1.");
$.lang.register("deathcounter.sub-zero", "Der Todeszähler für $1 steht derzeit auf 0 und kann nicht weiter runter!");
$.lang.register("deathcounter.counter", "$1 starb $3 Mal in $2!");
$.lang.register("deathcounter.none", "$1 ist in $2 noch nicht gestorben... bis jetzt.");
$.lang.register("deathcounter.reset", "Setze den Todeszähler für $1 von $2 auf 0 zurück.");
$.lang.register("deathcounter.reset-nil", "Der Todeszähler für $1 steht aktuell auf 0.");
