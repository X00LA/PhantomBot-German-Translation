$.lang.register('top5.default', 'Top $1 $2: $3');
$.lang.register('top5.points-disabled', 'Punkte sind deaktiviert.');
$.lang.register('top5.amount.points.usage', 'Verwendung: !topamount (Höhe) - Lege fest, wieviele BenutzerInnen in der !top Punkteliste erscheinen sollen.');
$.lang.register('top5.amount.max', 'Die maximale Anzahl sind 15 BenutzerInnen.');
$.lang.register('top5.amount.points.set', '$1 BenutzerInnen werden nun in der !top Punkteliste angezeigt.');
$.lang.register('top5.amount.time.usage', 'Verwendung: !toptimeamount (Höhe) - Lege fest, wieviele BenutzerInnen in der !toptime Zeitliste erscheinen sollen.');
$.lang.register('top5.amount.time.set', '$1 BenutzerInnen werden nun in der !toptime Zeitliste angezeigt.');
$.lang.register('top5.reloadtopbots', 'Neu geladene Liste von Bots/BenutzeInnen, die in Top-Befehlen ignoriert werden sollen.');
