$.lang.register('namechange.default', 'Verwendung: !namechange [Alter Name] [Neuer Name]');
$.lang.register('namechange.updating', 'Aktualisiere Name von $1 zu $2 in allen Datenbank Tabellen. Das kann etwas Zeit in Anspruch nehmen.');
$.lang.register('namechange.success', 'BenutzerInnenname $1 wurde in $3 Tabellen zu $2 geändert!');
$.lang.register('namechange.notfound', 'Der BenutzerInnenname $1 wurde in keiner Tabelle gefunden.');
