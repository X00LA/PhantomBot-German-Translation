$.lang.register('discord.roll.rolled', '$1 würfelte eine [$2] und [$3]. ');
$.lang.register('discord.roll.doubleone', 'Einserpasch für $1! ');
$.lang.register('discord.roll.doubletwo', 'Zweierpasch für $1! ');
$.lang.register('discord.roll.doublethree', 'Dreierpasch für $1! ');
$.lang.register('discord.roll.doublefour', 'Viererpasch für $1! ');
$.lang.register('discord.roll.doublefive', 'Fünferpasch für $1! ');
$.lang.register('discord.roll.doublesix', 'SECHSERPASCH!!! YEAH!!! $1! ');
$.lang.register('discord.roll.rewards.usage', 'Verwendung: !roll rewards [double 1\'s] [2\'s] [3\'s] [4\'s] [5\'s] [6\'s]. Aktuell: $1');
$.lang.register('discord.roll.rewards.success', 'Belohnungen für Würfelwürfe aktualisiert.');
