$.lang.register('discord.slotmachine.result.start', '$1: [ $2 $3 $4 ] ');
$.lang.register('discord.slotmachine.result.win', ' +$1 ');
$.lang.register('discord.slotmachine.rewards.usage', 'Verwendung: !slot rewards [val1] [val2] [val3] [val4] [val5]. Aktuell: $1');
$.lang.register('discord.slotmachine.rewards.success', 'Belohnungen für den Spielautomaten aktualisiert.');
