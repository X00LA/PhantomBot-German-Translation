$.lang.register('discord.streamlabshandler.usage', 'Verwendung: !streamlabshandler [toggle / message / channel]');
$.lang.register('discord.streamlabshandler.toggle', 'StreamLabs Spendenbenachrichtigungen wurden $1!');
$.lang.register('discord.streamlabshandler.message.usage', 'Verwendung: !streamlabshandler message [Nachricht] - Tags: (name) (amount) (currency) (message)');
$.lang.register('discord.streamlabshandler.message.set', 'StreamLabs Spendennachricht festgelegt zu: $1');
$.lang.register('discord.streamlabshandler.channel.usage', 'Verwendung: !streamlabshandler channel [Kanalname]');
$.lang.register('discord.streamlabshandler.channel.set', 'StreamLabs Spenden werden nun im Kanal #$1 ausgegeben!');
