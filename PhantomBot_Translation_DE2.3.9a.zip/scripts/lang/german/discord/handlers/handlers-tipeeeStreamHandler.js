$.lang.register('discord.tipeeestreamhandler.usage', 'Verwendung: !tipeeestreamhandler [toggle / message / channel]');
$.lang.register('discord.tipeeestreamhandler.toggle', 'TipeeeStream Spendenbenachrichtigungen wurden $1!');
$.lang.register('discord.tipeeestreamhandler.message.usage', 'Verwendung: !tipeeestreamhandler message [Nachricht] - Tags: (name) (amount) (currency) (formattedamount) (message)');
$.lang.register('discord.tipeeestreamhandler.message.set', 'TipeeeStream Spendenbenachrichtigungsnachricht wurde festgelegt zu: $1');
$.lang.register('discord.tipeeestreamhandler.channel.usage', 'Verwendung: !tipeeestreamhandler channel [Kanalname]');
$.lang.register('discord.tipeeestreamhandler.channel.set', 'TipeeeStream Spenden werden nun im Kanal #$1 ausgegeben!');
