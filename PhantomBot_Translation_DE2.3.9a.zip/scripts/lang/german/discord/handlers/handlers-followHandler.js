$.lang.register('discord.followhandler.usage', 'Verwendung: !followhandler [toggle / message / channel]');
$.lang.register('discord.followhandler.follow.toggle', 'Follow Benachrichtigungen wurden $1!');
$.lang.register('discord.followhandler.follow.message.usage', 'Verwendung: !followhandler message [Nachricht] - Tag: (name)');
$.lang.register('discord.followhandler.follow.message.set', 'Follow Benachrichtigungsnachricht wurde festgelegt zu: $1');
$.lang.register('discord.followhandler.follow.channel.usage', 'Verwendung: !followhandler channel [Kanalname]');
$.lang.register('discord.followhandler.follow.channel.set', 'Follow Benachrichtigungen werden nun im Kanal #$1 ausgegeben!');
