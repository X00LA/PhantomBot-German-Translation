$.lang.register('discord.streamtipshanlder.usage', 'Verwendung: !streamtiphandler [toggle / message / channel]');
$.lang.register('discord.streamtipshanlder.toggle', 'StreamTip Spendenbenachrichtigungen wurden $1!');
$.lang.register('discord.streamtipshanlder.message.usage', 'Verwendung: !streamtiphandler message [Nachricht] - Tags: (name) (amount) (currency) (message)');
$.lang.register('discord.streamtipshanlder.message.set', 'StreamTip Spendennachricht festgelegt zu: $1');
$.lang.register('discord.streamtipshanlder.channel.usage', 'Verwendung: !streamtiphandler channel [Kanalname]');
$.lang.register('discord.streamtipshanlder.channel.set', 'StreamTip Spenden werden nun im Kanal #$1 ausgegeben!');
