$.lang.register('discord.twitterhandler.usage', 'Verwendung: !twitterhandler [toggle / channel]');
$.lang.register('discord.twitterhandler.toggle', 'Twitter Benachrichtigungen wurden $1!');
$.lang.register('discord.twitterhandler.channel.usage', 'Verwendung: !twitterhandler channel [Kanalname]');
$.lang.register('discord.twitterhandler.channel.set', 'Twitter Benachrichtigungen werden nun im Kanal #$1 ausgegeben!');
