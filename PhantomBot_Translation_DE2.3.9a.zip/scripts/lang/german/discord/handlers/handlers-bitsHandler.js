$.lang.register('discord.bitshandler.usage', 'Verwendung: !bitshandler [toggle / message / channel]');
$.lang.register('discord.bitshandler.bits.toggle', 'Bit Benachrichtigungen wurden $1!');
$.lang.register('discord.bitshandler.bits.message.usage', 'Verwendung: !bitshandler message [Nachricht] - Tags: (name) (amount)');
$.lang.register('discord.bitshandler.bits.message.set', 'Bits Benachrichtigungsnachricht wurde festgelegt zu: $1');
$.lang.register('discord.bitshandler.bits.channel.usage', 'Verwendung: !bitshandler channel [Kanalname]');
$.lang.register('discord.bitshandler.bits.channel.set', 'Bits Benachrichtigungen werden nun im Kanal #$1 ausgegeben!');
