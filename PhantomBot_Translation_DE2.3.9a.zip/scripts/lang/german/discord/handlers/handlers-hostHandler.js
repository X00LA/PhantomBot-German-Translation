$.lang.register('discord.hosthandler.usage', 'Verwendung: !hosthandler [toggle / hostmessage / autohostmessage / channel]');
$.lang.register('discord.hosthandler.host.toggle', 'Host-Benachrichtigungen wurden $1!');
$.lang.register('discord.hosthandler.host.message.usage', 'Verwendung: !hosthandler hostmessage [Nachricht] - Tags: (name) (viewers)');
$.lang.register('discord.hosthandler.host.message.set', 'Host Nachricht wurde festgelegt zu: $1');
$.lang.register('discord.hosthandler.autohost.message.usage', 'Verwendung: !hosthandler autohostmessage [Nachricht] - Tags: (name) (viewers)');
$.lang.register('discord.hosthandler.autohost.message.set', 'Auto-Host Nachricht wurde festgelegt zu: $1.');
$.lang.register('discord.hosthandler.channel.usage', 'Verwendung: !hosthandler channel [Kanalname]');
$.lang.register('discord.hosthandler.channel.set', 'Host Benachrichtigungen werden nun im Kanal #$1 ausgegeben!');
