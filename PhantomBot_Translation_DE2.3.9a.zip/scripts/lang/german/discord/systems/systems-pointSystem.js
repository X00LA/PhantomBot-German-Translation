$.lang.register('discord.pointsystem.self.points', 'Aktuell besitzt du $1.'); // Use $2 to display the users time and $3 for the user's rank. The rank also has his name by default.
$.lang.register('discord.pointsystem.other.points', '$1 besitzt aktuell $2.'); // Use $3 to display the users time and $4 for the user's rank. The rank also has his name by default.
$.lang.register('discord.pointsystem.no.points.other', 'Diese/r BenutzerIn besitz derzeit keine $1.');
