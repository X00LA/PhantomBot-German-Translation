$.lang.register('discord.cooldown.coolcom.usage', 'Verwendung: !coolcom [Befehl] [Sekunden] [Type (global / user)] - Der Wert -1 bei den Sekunden entfernt die Abklingzeit.');
$.lang.register('discord.cooldown.coolcom.set', 'Die Abklingzeit für den Befehl !$1 wurde auf $2 Sekunden gesetzt.');
$.lang.register('discord.cooldown.coolcom.remove', 'Die Abklingzeit für den Befehl !$1 wurde entfernt.');
$.lang.register('discord.cooldown.cooldown.usage', 'Verwendung: !cooldown [setdefault]');
$.lang.register('discord.cooldown.default.set', 'Die Standard Abklingzeit für Befehle, welche keine eigene Abklingzeit haben, wurdeauf $1 Sekunden festgelegt.');
$.lang.register('discord.cooldown.default.usage', 'Verwendung: !cooldown setdefault [Sekunden] - Legt für Befehgle ohne eigene Abklingzeit eine globale Abklingzeit fest.');
